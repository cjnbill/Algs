#include <iostream>
#include "fileio.cpp"
#include <vector>
#include <unordered_map>

using namespace std;


int main(int argc,char *args[])
{
    ioprocess(args[1]);
    return 0;
}
