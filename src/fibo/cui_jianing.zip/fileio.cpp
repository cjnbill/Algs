#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>
#include "fiboheap.cpp"



using namespace std;

unordered_map<string, fibonode<int>*> hashtable;
unordered_map<fibonode<int>*, string> reversed;
fiboheap<int>* hb=new fiboheap<int>();


void reversehash(std::unordered_map<std::string, fibonode<int>*> &hashtable){
    for (unordered_map<string, fibonode<int>*>::iterator i = hashtable.begin(); i != hashtable.end(); ++i)
        reversed[i->second] = i->first;
}

void ioprocess(char* filename){
    ifstream infile(filename);
    string line;
    while (std::getline(infile, line))
    {
        istringstream iss(line);
        string a;
        int b;
        if (iss >> a >> b) {
            //the hashtag haven't store
            if ( hashtable.find(a) == hashtable.end() ) {
                fibonode<int>* pn=new fibonode<int>(b);
                hashtable[a]=pn;
                hb->insert(pn);
            } else {//already have this hashtag
                hb->increaseKey(hashtable[a],hashtable[a]->key+b);
            }
        }
        else
        {
            istringstream i(line);
            if(i >> b){//query
                ofstream ofile("output_file.txt",ios::app);
                vector<fibonode<int>*> vf;
                fibonode<int>* pn;
                while(b--){
                    reversehash(hashtable);
                    pn=new fibonode<int>(hb->getMax()->key);
                    hashtable[reversed[hb->getMax()]]=pn;
                    reversehash(hashtable);
                    vf.push_back(pn);
                    if(b==0)ofile<<reversed[hb->getMax()].substr(1);
                    else ofile<<reversed[hb->getMax()].substr(1)<<",";
                    hb->removeMax();

                }
                ofile<<"\n";
                for(int i=0;i<vf.size();i++){
                    hb->insert(vf[i]);
                }
                ofile.close();
            }
            else{//stop
                break;
            }
        }
    }
    infile.close();
}
